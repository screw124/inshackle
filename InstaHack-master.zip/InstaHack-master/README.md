# Inshackle v1.0
## Author: github.com/thelinuxchoice/inshackle
## IG: instagram.com/linux_choice
### Don't copy this code without give me the credits, nerd! Please read the License 

Instagram hacks: Track unfollowers, Increase your followers, Download Stories, etc

### Features:
#### Unfollow Tracker
#### Increase Followers
#### Download: Stories, Saved Content, Following/followers list, Profile Info
#### Unfollow all your following

![ins](https://user-images.githubusercontent.com/34893261/53686880-d50f6000-3d0b-11e9-8c42-cab1ad30b24e.png)

### Usage:
```
git clone https://github.com/thelinuxchoice/inshackle
cd inshackle
bash inshackle.sh
```

### Donate!
Support the authors:
### Paypal:
https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=CLKRT5QXXFJY4&source=url
### LiberaPay:
<noscript><a href="https://liberapay.com/thelinuxchoice/donate"><img alt="Donate using Liberapay" src="https://liberapay.com/assets/widgets/donate.svg"></a></noscript>
